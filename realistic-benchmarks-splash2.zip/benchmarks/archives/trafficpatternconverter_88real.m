% Traffic pattern converter.
% Read the input, convert to two type of patterns:
% 1. For CPLEX. (D1: each sd pair)
% 2. For LINCA-enhanced. (D3: one source to all dests)
% 8x8
% Outputs:
% D1: each sdpair
% D3: one source to many destinations.

clear; clc;

n = 64; % num. nodes
% n = 256; % num. nodes
% n = 512; % num. nodes

% fid = fopen('ffm88.txt');
% fid = fopen('lucontig88.txt');
% fid = fopen('cholesky88.txt');
% fid = fopen('radix88.txt');
% fid = fopen('raytrace88.txt');
% fid = fopen('waternsquared88.txt');
% fid = fopen('waterspatial88.txt');
fid = fopen('oceancontig88.txt');
% ----------------------------


n2 = n*n; % 64*64=4096(row)
D = zeros(n2,n); % (row,col)
[rowsD,colsD] = size(D);

A = zeros(n,n); % nxn matrix
[rowsA, colsA] =size(A);
tline = fgetl(fid);

countD=0;
count01=0;
while ischar(tline)
	str = length(tline);
	[s s1 d1 v1] = strread(tline, '%s %d %d %f', 'delimiter',' ');

	v1 = round(v1);

	for i= 1:rowsA % row
		for j = 1:colsA %col
			if i==(s1+1) & j==(d1+1)
				A((s1+1),(d1+1))=A((s1+1),(d1+1))+v1;
			end
		end
	end
	
	% D(each)
	countD=countD+1;
	for ii=1:colsD
		if (s1+1)==(d1+1)
		else
			if (s1+1) ==ii % source
				D(countD,ii) = -v1;
				count01 = count01+1;
			end
			if (d1+1) ==ii % dest
				D(countD,ii) = v1;
				count01 = count01+1;
			end
			if count01==2
				count01 = 0;
				break;
			end
		end
	end
	%-------
	tline=fgetl(fid); % increment.
end

fclose(fid);

D1 = zeros(n2,n); % (r,c)

countD1=0;
countD2=0;
for i=1:n % cols
	while countD1 ~= n2 % rows
		countD1 = countD1+1;
		if D(countD1,i) < 0
			countD2=countD2+1;
			D1(countD2,:) = D(countD1,:);
		end
	end
	countD1=0; % reset
end

D1(~any(D1,2),:) = []; %delete zeros rows

% display(D1); % one source to many destinations.
[rowsD1, colsD1] = size(D1);
% sum D1 to D3.
D2 = zeros(n2,n); % (r,c)
D3 = zeros(n,n); % (r,c)
countDx=0;
countDx1=0;
for i = 1: colsD1
	for j = 1: rowsD1
		if D1(j,i)<0
			countDx=countDx+1;
			D2(countDx,:) = D1(j,:);
		end
	end
	countDx1 = countDx1+1;
	D3(countDx1,:) = sum(D2);
	D2 = zeros(n2,n); % reset
end

D3(~any(D3,2),:) = []; %delete zeros rows
display(D3);

% ----------------------
% Save to file txt
% ----------------------
% % Write D1 to file.
% ----------------------------

% fidx = fopen('output/output_D1_ffm88.txt','wt');
% fidx = fopen('output/output_D1_lucontig88.txt','wt');
% fidx = fopen('output/output_D1_cholesky88.txt','wt');
% fidx = fopen('output/output_D1_radix88.txt','wt');
% fidx = fopen('output/output_D1_raytrace88.txt','wt');
% fidx = fopen('output/output_D1_waternsquared88.txt','wt');
% fidx = fopen('output/output_D1_waterspatial88.txt','wt');
fidx = fopen('output/output_D1_oceancontig88.txt','wt');


for ii = 1:size(D1,1)
    fprintf(fidx,'%g\t',D1(ii,:));
    fprintf(fidx,'\n');
end
fclose(fidx)

% % Write D3 to file.
% fidy = fopen('output/output_D3_ffm88.txt','wt');
% fidy = fopen('output/output_D3_lucontig88.txt','wt');
% fidy = fopen('output/output_D3_cholesky88.txt','wt');
% fidy = fopen('output/output_D3_radix88.txt','wt');
% fidy = fopen('output/output_D3_raytrace88.txt','wt');
% fidy = fopen('output/output_D3_waternsquared88.txt','wt');
% fidy = fopen('output/output_D3_waterspatial88.txt','wt');
fidy = fopen('output/output_D3_oceancontig88.txt','wt');
% ----------------------
for ii = 1:size(D3,1)
    fprintf(fidy,'%g\t',D3(ii,:));
    fprintf(fidy,'\n');
end
fclose(fidy)
